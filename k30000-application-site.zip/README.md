# K30,000 Application Website

An independent Next.js application-page template.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

1. Upload this project to GitHub.
2. In Vercel, import the GitHub repository.
3. Vercel should detect Next.js automatically.
4. Click Deploy.

## Important

This template intentionally avoids representing itself as an official bank, government, NGO, or public-official program. The form is a front-end demonstration and does not store submissions in a database.
