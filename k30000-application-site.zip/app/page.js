"use client";

import { useState } from "react";

export default function Home() {
  const [submitted, setSubmitted] = useState(false);

  function submit(e) {
    e.preventDefault();
    setSubmitted(true);
  }

  return (
    <main>
      <section className="hero">
        <div className="badge">INDEPENDENT APPLICATION PAGE</div>
        <h1>Congratulations!</h1>
        <p className="lead">
          You may be eligible to apply for a potential support amount of
          <strong> K30,000</strong>.
        </p>
        <div className="amount">K30,000</div>
        <p className="note">
          Eligibility is subject to verification and does not guarantee payment.
        </p>
      </section>

      <section className="card">
        {!submitted ? (
          <>
            <h2>Application Space</h2>
            <p className="muted">
              Complete the form below to submit an application for review.
            </p>

            <form onSubmit={submit}>
              <label>
                Full name
                <input name="name" required placeholder="Enter your full name" />
              </label>

              <label>
                Phone number
                <input name="phone" required placeholder="Enter your phone number" />
              </label>

              <label>
                Location
                <input name="location" required placeholder="City / Country" />
              </label>

              <label>
                Occupation
                <input name="occupation" placeholder="Your occupation" />
              </label>

              <label>
                Amount requested
                <input value="K30,000" readOnly />
              </label>

              <label className="check">
                <input type="checkbox" required />
                <span>I understand that submitting this form does not guarantee approval or payment.</span>
              </label>

              <button type="submit">Submit Application</button>
            </form>
          </>
        ) : (
          <div className="success">
            <div className="checkmark">✓</div>
            <h2>Application Submitted</h2>
            <p>
              Your application has been recorded on this page for demonstration
              purposes. Any real funding decision must be confirmed by the
              responsible organization through its official channels.
            </p>
            <button onClick={() => setSubmitted(false)}>Submit Another Application</button>
          </div>
        )}
      </section>

      <section className="info">
        <h2>Important Information</h2>
        <ul>
          <li>This is an independent application template.</li>
          <li>It is not an official bank, government, NGO, or public-official website.</li>
          <li>Do not send registration fees, PINs, passwords, or one-time verification codes through this page.</li>
          <li>Verify any funding offer directly with the responsible organization before making a payment or sharing sensitive information.</li>
        </ul>
      </section>

      <footer>
        © {new Date().getFullYear()} Independent Application Information
      </footer>
    </main>
  );
}
