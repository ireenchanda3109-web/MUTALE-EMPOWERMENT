import "./globals.css";

export const metadata = {
  title: "K30,000 Support Application",
  description: "Independent application information and eligibility form."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
