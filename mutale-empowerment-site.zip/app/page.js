 "use client";
import {useState} from "react";
const WHATSAPP_NUMBER="254747985615";
export default function Page(){
 const [form,setForm]=useState({names:"",phone:"",job:"",location:"",amount:""});
 const update=(k,v)=>setForm({...form,[k]:v});
 const message=`Hello, I would like to submit an application.%0A%0AFull names: ${encodeURIComponent(form.names)}%0AActive phone number: ${encodeURIComponent(form.phone)}%0AOccupation/current job: ${encodeURIComponent(form.job)}%0ALocation: ${encodeURIComponent(form.location)}%0AAmount requested: ${encodeURIComponent(form.amount)}`;
 const send=()=>window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`,"_blank");
 return <main><header><div className="logo">MUTALE EMPOWERMENT</div><a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank">WhatsApp</a></header>
 <section className="wrap"><div className="intro"><span>APPLICATION PORTAL</span><h1>Mutale Empowerment</h1><p>Complete the application details below, then submit them through our WhatsApp contact.</p></div>
 <form onSubmit={e=>{e.preventDefault();send()}}>
 <label>1 📌 Full names<input required value={form.names} onChange={e=>update("names",e.target.value)} placeholder="Enter your full names"/></label>
 <label>2 📌 Active phone number<input required type="tel" value={form.phone} onChange={e=>update("phone",e.target.value)} placeholder="+254 7XX XXX XXX"/></label>
 <label>3 📌 Occupation/current job<input required value={form.job} onChange={e=>update("job",e.target.value)} placeholder="Enter occupation or current job"/></label>
 <label>4 📌 Location<input required value={form.location} onChange={e=>update("location",e.target.value)} placeholder="City / town / area"/></label>
 <label>5 📌 Amount you need to apply<input required inputMode="decimal" value={form.amount} onChange={e=>update("amount",e.target.value)} placeholder="Enter amount"/></label>
 <div className="actions"><button type="submit">Submit Application</button><button type="button" className="whatsapp" onClick={send}>WhatsApp</button></div>
 </form><p className="notice">Your details are placed into a WhatsApp message for you to review before sending. This page does not by itself guarantee approval or payment.</p>
 </section></main>
}