import "./globals.css";
export const metadata={title:"Mutale Empowerment | Application",description:"Application page for Mutale Empowerment."};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}