const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "CHANGE-ME-BEFORE-DEPLOYING";
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");

const db = new Database(path.join(__dirname, "applications.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reference TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  nrc TEXT NOT NULL,
  district TEXT NOT NULL,
  category TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Submitted',
  created_at TEXT NOT NULL
);
`);

app.use(express.json({limit:"50kb"}));
app.use(express.urlencoded({extended:false}));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {httpOnly:true, sameSite:"lax", secure: process.env.NODE_ENV==="production", maxAge: 2*60*60*1000}
}));
app.use(express.static(path.join(__dirname, "public")));

function auth(req,res,next){
  if(req.session && req.session.admin) return next();
  res.status(401).json({error:"Unauthorized"});
}
function ref(){
  return "ME-" + Date.now().toString().slice(-8) + "-" + crypto.randomBytes(2).toString("hex").toUpperCase();
}

app.post("/api/applications", (req,res)=>{
  const {full_name,phone,nrc,district,category} = req.body;
  if(!full_name || !phone || !nrc || !district || !category)
    return res.status(400).json({error:"All fields are required."});
  const reference = ref();
  const created_at = new Date().toISOString();
  db.prepare(`INSERT INTO applications
    (reference,full_name,phone,nrc,district,category,created_at)
    VALUES (?,?,?,?,?,?,?)`)
    .run(reference,String(full_name).trim(),String(phone).trim(),String(nrc).trim(),
         String(district).trim(),String(category).trim(),created_at);
  res.json({reference});
});

app.post("/api/admin/login",(req,res)=>{
  if(req.body.password !== ADMIN_PASSWORD) return res.status(401).json({error:"Invalid password"});
  req.session.admin = true;
  res.json({ok:true});
});
app.post("/api/admin/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/admin/applications",auth,(req,res)=>{
  const rows = db.prepare("SELECT * FROM applications ORDER BY id DESC").all();
  res.json(rows);
});

app.patch("/api/admin/applications/:id",auth,(req,res)=>{
  const allowed = ["Submitted","Under Review","Eligible","Not Eligible","Approved","Rejected"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE applications SET status=? WHERE id=?").run(req.body.status,req.params.id);
  res.json({ok:true});
});

app.get("/api/admin/export.csv",auth,(req,res)=>{
  const rows = db.prepare("SELECT reference,full_name,phone,nrc,district,category,status,created_at FROM applications ORDER BY id DESC").all();
  const esc=v=>`"${String(v??"").replace(/"/g,'""')}"`;
  const csv=["Reference,Full Name,Phone,NRC,District,Category,Status,Created At",
    ...rows.map(r=>[r.reference,r.full_name,r.phone,r.nrc,r.district,r.category,r.status,r.created_at].map(esc).join(","))].join("\n");
  res.setHeader("Content-Type","text/csv");
  res.setHeader("Content-Disposition","attachment; filename=mutale-applications.csv");
  res.send(csv);
});

app.listen(PORT,()=>console.log(`Application system running on http://localhost:${PORT}`));
